
import { initClient } from '@ts-rest/core';
import { financialContract } from '@contracts/contracts/financial';

export const createFinancialClient = (baseUrl: string, getHeaders?: () => Record<string, string>) => {
  return initClient(financialContract, { baseUrl, baseHeaders: getHeaders });
};
