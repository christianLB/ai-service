# @clients/financial – SDK generado desde contrato de Finanzas
